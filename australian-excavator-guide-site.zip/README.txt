AUSTRALIAN EXCAVATOR GUIDE — STARTER WEBSITE
================================================

Files:
- index.html
- equipment.html
- blog.html
- price-guide.html
- about.html
- faq.html
- contact.html
- privacy.html
- disclaimer.html
- styles.css

IMPORTANT BEFORE PUBLISHING
1. Replace hello@example.com in contact.html with the real mailbox.
2. Replace the illustrative remote images with licensed/client-owned images where possible.
3. Review the privacy policy for the actual hosting, analytics, cookies and contact-form setup.
4. Review all external links and current supplier details before publishing.
5. The site is deliberately written as an independent educational resource and should not be presented as an official Digger King property.

DIGGER KING LINKS INCLUDED
- https://diggerking.com.au/
- https://diggerking.com.au/pricelist/
- https://diggerking.com.au/videotours/
- https://diggerking.com.au/warranty-and-guarantee/
- https://diggerking.com.au/yourdigger/
- https://diggerking.com.au/contact-us/

IMAGE NOTE
The starter pages use remote illustrative images so the layout works immediately. Before commercial publication, replace them with images you own, have permission to use, or have sourced under an appropriate licence.
